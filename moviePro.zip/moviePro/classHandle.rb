require './moviePro'
require 'set'
module MYP
  class ClassHandle
    def self.handle(paths, classes)
      swiftClasses = SwiftClassHandle.handle(paths, classes)
      objcClasses = ObjcClassHandle.handle(paths, classes)
      (swiftClasses || []) + (objcClasses || [])
    end
  end
end

module MYP
  class SwiftClassHandle < ClassHandle
    def self.handle(paths, classes)
      containsClasses = Set.new
      paths.each_with_index do |path, index|
        content = File.open(path).read
        classes.each do |swift|
          classRegrexp = /\=?:?[^(class)]\s*\(?#{swift.name}\s*[^:][.\(?!,]?/
          containsClasses.add(swift) if content.match?(classRegrexp)
        end
        Progress.loading(index, paths.count)
      end
      cellitems = containsClasses.find_all {|swift| swift.name =~ /Item$/ }
      cellitems.each { |swift| swift.name.sub!(/Item$/, 'Cell') }
      containsClasses += cellitems
      containsClasses.each do |classItem|
        classes.delete_if {|item| item.name == classItem.name }
      end
      classes
    end
  end
end

module MYP
  class ObjcClassHandle < ClassHandle
    def self.handle(paths, classes)
      []
    end
  end
end
